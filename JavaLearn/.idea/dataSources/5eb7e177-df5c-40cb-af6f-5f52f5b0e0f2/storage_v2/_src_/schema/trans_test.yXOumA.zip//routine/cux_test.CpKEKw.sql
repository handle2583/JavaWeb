create
    definer = transuser_test@`%` procedure cux_test()
begin 
 
declare num int default 1;
while num < 30000 do 

insert into cux_gb_adjust_lines(
  `ledger_name` ,--
	`je_desc` ,#varchar(240) DEFAULT NULL COMMENT '日记账说明',
	`je_source` ,#varchar(25) NOT NULL COMMENT '日记账来源',
	`je_category` ,#varchar(25) NOT NULL COMMENT '日记账类别',
	`period_name` ,#varchar(15) NOT NULL COMMENT '期间',
	`gl_date` ,#varchar(10) NOT NULL COMMENT '记账日期',
	`currency_code` ,#varchar(15) NOT NULL COMMENT '币种',
	`exchange_type` ,#varchar(30) DEFAULT NULL COMMENT '汇率类型',
	`exchange_date` ,#varchar(10) DEFAULT NULL COMMENT '汇率日期YYYY-MM-DD',
	`exchange_rate` ,#decimal(40) DEFAULT NULL COMMENT '汇率',
	`segment1` ,#varchar(150) NOT NULL COMMENT '主体段',
	`segment2` ,#varchar(150) NOT NULL COMMENT '成本中心段',
	`segment3`,#varchar(150) NOT NULL COMMENT '科目段',
	`segment4` ,#varchar(150) NOT NULL COMMENT '辅助科目段',
	`segment5` ,#varchar(150) NOT NULL COMMENT '利润中心段',
	`segment6` ,#varchar(150) NOT NULL COMMENT '产品段',
	`segment7` ,#varchar(150) NOT NULL COMMENT '项目段',
	`segment8` ,#varchar(150) NOT NULL COMMENT '公司间段',
	`segment9` ,#varchar(150) NOT NULL COMMENT '备用段1',
	`segment10` ,#varchar(150) NOT NULL COMMENT '备用段2',
	`dr_amount` ,#decimal(30)  COMMENT '借方金额',
	`cr_amount`,# decimal(30)  COMMENT '贷方金额',
	`line_desc` ,#varchar(240) DEFAULT NULL COMMENT '行说明',
	`city_code`,# varchar(150) DEFAULT NULL COMMENT '城市',
	`dr_amount_base` ,#decimal(30)  COMMENT '本位币借方金额',
	`cr_amount_base`,# decimal(30)  COMMENT '本位币贷方金额',
	`dw_id` ,#bigint(30) NOT NULL COMMENT '数仓唯一标识',
	`dw_header_id` ,#bigint(30) NOT NULL COMMENT '数仓头标识',
	`dw_line_id`)
values ('DIDI_BU_CNY','AAA','管报调整','管报调整','2020-06','2020-06-03','USD',
'User','2020-01-01',6.5969484848484848484,'120300','0','10010101','0','0','0','0','0','0','0',100.345,null,'好的',
null,600.888,null,1234554321,1234554321,null
);
#SELECT concat('myvar is ', num);
 set num=num+1;
end while;
end;

