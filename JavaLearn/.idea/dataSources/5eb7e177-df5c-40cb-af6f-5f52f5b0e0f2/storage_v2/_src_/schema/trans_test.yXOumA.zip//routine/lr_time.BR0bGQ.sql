create
    definer = transuser_test@`%` procedure lr_time()
begin
    declare n int default 1;
    declare MAX int default 4;
    while n < MAX do
        set n = n + 1;		
SELECT concat('myvar is ', n);
    end while;
end;

